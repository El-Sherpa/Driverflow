import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TranslationService {
  private currentLanguage = new BehaviorSubject<string>('es');
  currentLanguage$ = this.currentLanguage.asObservable();

  private translations: any = {
    es: {
      // General
      AJUSTES: 'AJUSTES',
      PREFERENCIAS: 'PREFERENCIAS',
      NOTIFICACIONES: 'Notificaciones Push',
      NOTIFICACIONES_DESC: 'Alertas de velocidad y geocercas',
      MODO_OSCURO: 'Modo Oscuro',
      MODO_OSCURO_DESC: 'Interfaz de alto contraste neón',
      SISTEMA: 'SISTEMA',
      IDIOMA: 'Idioma',
      FRECUENCIA_GPS: 'Frecuencia GPS',
      FRECUENCIA_GPS_DESC: 'Intervalo de actualización (seg)',
      GUARDAR: 'GUARDAR CAMBIOS',
      USUARIOS: 'Usuarios',
      FILTRAR_ROL: 'Filtrar por rol',
      BUSCAR_USUARIO: 'Buscar (username, nombre, email)',
      ACTIVO: 'ACTIVO',
      BLOQUEADO: 'BLOQUEADO',
      ESTADO_ACCESO: 'Estado de Acceso',
      BIENVENIDO: 'Bienvenido',
      VOLVER: 'Volver',
      CERRAR_SESION: 'Cerrar Sesión',
      SISTEMA_CONTROL_GPS: 'SISTEMA DE CONTROL GPS',
      HOLA: 'Hola',
      FLUJO_REGISTROS_HOY: 'Flujo de Registros (Hoy)',
      NUEVOS_HOY: 'Nuevos Hoy',
      EXITOSOS: 'Exitosos',
      PENDIENTE: 'PENDIENTE',
      EXITOSO: 'EXITOSO',
      
      // Menú Lateral
      MI_PERFIL: 'Mi Perfil',
      DASHBOARD: 'Dashboard',
      MI_VEHICULO: 'Mi Vehículo',
      GPS: 'GPS',
      ADMINISTRACION: 'ADMINISTRACIÓN',
      AGENTES: 'Agentes',
      CLIENTES: 'Clientes',
      DISPOSITIVOS: 'Dispositivos',
      GESTION: 'GESTIÓN',
      CODIGO_EMPRESA: 'Código Empresa',
      ASIGNAR_VEHICULO: 'Asignar Vehículo',
      PAGOS_PLANES: 'Pagos y Planes',
      ADMIN_PANEL: 'Panel Admin',
      MAPA_GPS: 'Mapa GPS',
      
      // Dashboards
      ESTADISTICAS: 'Estadísticas',
      VEHICULOS_ACTIVOS: 'Vehículos Activos',
      ALERTAS_HOY: 'Alertas Hoy',
      ESTADO_FLOTA: 'Estado de la Flota',
      ACTIVIDAD_RECIENTE: 'ACTIVIDAD RECIENTE',
      SIN_ACTIVIDAD: 'No hay actividad reciente',
      
      // Vehículo / GPS
      DETALLES_VEHICULO: 'Detalles del Vehículo',
      PLACA: 'Placa',
      MODELO: 'Modelo',
      ESTADO_GPS: 'Estado GPS',
      ENCENDER_GPS: 'Encender GPS',
      APAGAR_GPS: 'Apagar GPS',
      TRAZAR_RUTA: 'Trazar Ruta',
      GPS_DESTINATION: 'Destino',
      GPS_CALCULATING_ROUTE: 'Calculando ruta',
      GPS_CLEAR_ROUTE: 'Limpiar ruta',
      GPS_SEARCH_PLACEHOLDER: 'Ingresa una dirección',
      GPS_ON: 'Encender',
      GPS_OFF: 'Apagar',
      GPS_DESACTIVADO: 'GPS Desactivado',
      PULSA_ENCENDER_PARA_RASTREAR_UBICACION: 'Pulsa encender para rastrear ubicación',
      INGRESA_UNA_DIRECCION: 'Ingresa una dirección',
      APAGAR: 'Apagar',
      ENCENDER: 'Encender',
      
      // Planes
      SELECCIONAR_PLAN: 'Seleccionar Plan',
      MENSUAL: 'Mensual',
      ANUAL: 'Anual',
      AHORRA_20: 'Ahorra 20%',
      MONEDA: 'Moneda',
      SUSCRIBIRSE: 'Suscribirse',
      CICLO: 'Ciclo',
      SELECCIONA_EL_PLAN_QUE_MEJOR_SE_AJUSTE_A_TU_EMPRESA_Y_PROCEDE_AL_PAGO: 'Selecciona el plan que mejor se ajuste a tu empresa y procede al pago',
      
      // Perfil
      DATOS_PERSONALES: 'DATOS PERSONALES',
      NOMBRE_COMPLETO: 'Nombre Completo',
      IDENTIFICACION: 'Identificación',
      TELEFONO: 'Teléfono',
      CIUDAD: 'Ciudad',
      DIRECCION: 'Dirección',
      GENERO: 'Género',
      FECHA_NACIMIENTO: 'Fecha de Nacimiento',
      VINCULACION_EMPRESA: 'VINCULACIÓN EMPRESA',
      CODIGO_ACCESO: 'Código de Empresa',
      INGRESA_CODIGO: 'Ingresa el código de 6 dígitos',
      VINCULAR: 'VINCULAR AHORA',
      ACTUALIZAR_DATOS: 'ACTUALIZAR DATOS',
      NOMBRE_USUARIO: 'Nombre de Usuario',
      EMAIL: 'Correo Electrónico',
      NUMERO_IDENTIFICACION: 'Número de Identificación',
      RH: 'RH',
      GRUPO_SANGUINEO: 'Grupo Sanguíneo',
      NOMBRES: 'Nombres',
      APELLIDOS: 'Apellidos',
      AÑO_NACIMIENTO: 'Año de Nacimiento',
      LINK_FOTO_PERFIL: 'Enlace Foto de Perfil',
      ACTUALIZAR_PERFIL: 'Actualizar Perfil',

      // Agentes y Clientes
      FILTRAR_POR: 'Filtrar por',
      TOTAL: 'Total',
      ESTADO: 'Estado',
      ACCIONES: 'Acciones',
      TELEFONO_ABBR: 'Tel',
      CIUDAD_ABBR: 'Ciu',
      MODO_LISTA: 'Vista Lista',
      MODO_TARJETAS: 'Vista Tarjetas',
      ACTIVOS: 'Activos',
      INACTIVOS: 'Inactivos',
      BUSCAR: 'Buscar',
      AGENTES_DE_LA_EMPRESA: 'Agentes de la Empresa',
      AQUI_PODRAS_VER_Y_GESTIONAR_LOS_AGENTES_ASOCIADOS_A_TU_EMPRESA: 'Aquí podrás ver y gestionar los agentes asociados a tu empresa.',
      BUSCAR_POR_NOMBRE_IDENTIFICACION_O_PLACA: 'Buscar por nombre, identificación o placa',
      ID: 'ID',
      CELULAR: 'Celular',
      SOAT: 'SOAT',
      CLIENTES_DE_LA_EMPRESA: 'Clientes de la Empresa',
      AQUI_PODRAS_VER_Y_GESTIONAR_LOS_CLIENTES_ASOCIADOS_A_TU_EMPRESA: 'Aquí podrás ver y gestionar los clientes asociados a tu empresa.',
      MOSTRAR: 'Mostrar',
      FUNCIONARIOS: 'Funcionarios',
      PIME: 'PIME',
      TODOS: 'Todos',
      
      // Dispositivos
      MIS_DISPOSITIVOS: 'Dispositivos',
      DISPOSITIVOS_ACTIVOS: 'Dispositivos Activos',
      DISPOSITIVOS_INACTIVOS: 'Dispositivos Inactivos',
      SERIAL: 'Serial',
      TIPO: 'Tipo',
      GESTIÓN_DE_DISPOSITIVOS_GPS: 'Gestión de Dispositivos GPS',
      BUSCAR_POR_PLACA: 'Buscar por placa',
      VEHÍCULOS_CON_GPS_ACTIVO: 'Vehículos con GPS Activo',
      NO_HAY_VEHÍCULOS_CON_GPS_ACTIVO: 'No hay vehículos con GPS activo',
      VEHÍCULOS_CON_GPS_INACTIVO: 'Vehículos con GPS Inactivo',
      NO_HAY_VEHÍCULOS_CON_GPS_INACTIVO: 'No hay vehículos con GPS inactivo',
      
      // Asignar Vehículo
      VEHICULO: 'Vehículo',
      USUARIO: 'Usuario',
      FECHA_ASIGNACION: 'Fecha de Asignación',
      ASIGNAR: 'ASIGNAR VEHÍCULO',
      PROCESANDO: 'PROCESANDO'
    },
    en: {
      // General
      AJUSTES: 'SETTINGS',
      PREFERENCIAS: 'PREFERENCES',
      NOTIFICACIONES: 'Push Notifications',
      NOTIFICACIONES_DESC: 'Speed alerts and geofencing',
      MODO_OSCURO: 'Dark Mode',
      MODO_OSCURO_DESC: 'Neon high-contrast interface',
      SISTEMA: 'SYSTEM',
      IDIOMA: 'Language',
      FRECUENCIA_GPS: 'GPS Frequency',
      FRECUENCIA_GPS_DESC: 'Update interval (sec)',
      GUARDAR: 'SAVE CHANGES',
      USUARIOS: 'Users',
      FILTRAR_ROL: 'Filter by role',
      BUSCAR_USUARIO: 'Search (username, name, email)',
      ACTIVO: 'ACTIVE',
      BLOQUEADO: 'BLOCKED',
      ESTADO_ACCESO: 'Access Status',
      BIENVENIDO: 'Welcome',
      VOLVER: 'Back',
      CERRAR_SESION: 'Logout',
      SISTEMA_CONTROL_GPS: 'GPS CONTROL SYSTEM',
      HOLA: 'Hello',
      FLUJO_REGISTROS_HOY: 'Registration Flow (Today)',
      NUEVOS_HOY: 'New Today',
      EXITOSOS: 'Successful',
      PENDIENTE: 'PENDING',
      EXITOSO: 'SUCCESSFUL',
      
      // Side Menu
      MI_PERFIL: 'My Profile',
      DASHBOARD: 'Dashboard',
      MI_VEHICULO: 'My Vehicle',
      GPS: 'GPS',
      ADMINISTRACION: 'ADMINISTRATION',
      AGENTES: 'Agents',
      CLIENTES: 'Customers',
      DISPOSITIVOS: 'Devices',
      GESTION: 'MANAGEMENT',
      CODIGO_EMPRESA: 'Company Code',
      ASIGNAR_VEHICULO: 'Assign Vehicle',
      PAGOS_PLANES: 'Payments & Plans',
      ADMIN_PANEL: 'Admin Panel',
      MAPA_GPS: 'GPS Map',

      // Dashboards
      ESTADISTICAS: 'Statistics',
      VEHICULOS_ACTIVOS: 'Active Vehicles',
      ALERTAS_HOY: "Today's Alerts",
      ESTADO_FLOTA: 'Fleet Status',
      ACTIVIDAD_RECIENTE: 'RECENT ACTIVITY',
      SIN_ACTIVIDAD: 'No recent activity',

      // Vehicle / GPS
      DETALLES_VEHICULO: 'Vehicle Details',
      PLACA: 'Plate',
      MODELO: 'Model',
      ESTADO_GPS: 'GPS Status',
      ENCENDER_GPS: 'Turn On GPS',
      APAGAR_GPS: 'Turn Off GPS',
      TRAZAR_RUTA: 'Draw Route',
      GPS_DESTINATION: 'Destination',
      GPS_CALCULATING_ROUTE: 'Calculating route',
      GPS_CLEAR_ROUTE: 'Clear Route',
      GPS_SEARCH_PLACEHOLDER: 'Enter an address',
      GPS_ON: 'On',
      GPS_OFF: 'Off',
      GPS_DESACTIVADO: 'GPS Disabled',
      PULSA_ENCENDER_PARA_RASTREAR_UBICACION: 'Press on to track location',
      INGRESA_UNA_DIRECCION: 'Enter an address',
      APAGAR: 'Off',
      ENCENDER: 'On',

      // Planes
      SELECCIONAR_PLAN: 'Select Plan',
      MENSUAL: 'Monthly',
      ANUAL: 'Yearly',
      AHORRA_20: 'Save 20%',
      MONEDA: 'Currency',
      SUSCRIBIRSE: 'Subscribe',
      CICLO: 'Cycle',
      SELECCIONA_EL_PLAN_QUE_MEJOR_SE_AJUSTE_A_TU_EMPRESA_Y_PROCEDE_AL_PAGO: 'Select the plan that best fits your company and proceed to payment',

      // Profile
      DATOS_PERSONALES: 'PERSONAL DATA',
      NOMBRE_COMPLETO: 'Full Name',
      IDENTIFICACION: 'ID Number',
      TELEFONO: 'Phone',
      CIUDAD: 'City',
      DIRECCION: 'Address',
      GENERO: 'Gender',
      FECHA_NACIMIENTO: 'Birth Date',
      VINCULACION_EMPRESA: 'COMPANY LINKING',
      CODIGO_ACCESO: 'Company Code',
      INGRESA_CODIGO: 'Enter the 6-digit code',
      VINCULAR: 'LINK NOW',
      ACTUALIZAR_DATOS: 'UPDATE DATA',
      NOMBRE_USUARIO: 'Username',
      EMAIL: 'Email Address',
      NUMERO_IDENTIFICACION: 'Identification Number',
      RH: 'RH',
      GRUPO_SANGUINEO: 'Blood Group',
      NOMBRES: 'First Names',
      APELLIDOS: 'Last Names',
      AÑO_NACIMIENTO: 'Birth Year',
      LINK_FOTO_PERFIL: 'Profile Photo Link',
      ACTUALIZAR_PERFIL: 'Update Profile',

      // Agents and Clients
      FILTRAR_POR: 'Filter by',
      TOTAL: 'Total',
      ESTADO: 'Status',
      ACCIONES: 'Actions',
      TELEFONO_ABBR: 'Tel',
      CIUDAD_ABBR: 'City',
      MODO_LISTA: 'List View',
      MODO_TARJETAS: 'Card View',
      ACTIVOS: 'Active',
      INACTIVOS: 'Inactive',
      BUSCAR: 'Search',
      AGENTES_DE_LA_EMPRESA: 'Company Agents',
      AQUI_PODRAS_VER_Y_GESTIONAR_LOS_AGENTES_ASOCIADOS_A_TU_EMPRESA: 'Here you can view and manage the agents associated with your company.',
      BUSCAR_POR_NOMBRE_IDENTIFICACION_O_PLACA: 'Search by name, ID or plate',
      ID: 'ID',
      CELULAR: 'Cell Phone',
      SOAT: 'SOAT',
      CLIENTES_DE_LA_EMPRESA: 'Company Clients',
      AQUI_PODRAS_VER_Y_GESTIONAR_LOS_CLIENTES_ASOCIADOS_A_TU_EMPRESA: 'Here you can view and manage the clients associated with your company.',
      MOSTRAR: 'Show',
      FUNCIONARIOS: 'Staff',
      PIME: 'PIME',
      TODOS: 'All',

      // Devices
      MIS_DISPOSITIVOS: 'Devices',
      DISPOSITIVOS_ACTIVOS: 'Active Devices',
      DISPOSITIVOS_INACTIVOS: 'Inactive Devices',
      SERIAL: 'Serial',
      TIPO: 'Type',

      // Assign Vehicle
      VEHICULO: 'Vehicle',
      USUARIO: 'User',
      FECHA_ASIGNACION: 'Assignment Date',
      ASIGNAR: 'ASSIGN VEHICLE',
      PROCESANDO: 'PROCESSING'
    }
  };

  constructor() {
    const savedLang = localStorage.getItem('lang');
    if (savedLang) {
      this.currentLanguage.next(savedLang);
    }
  }

  setLanguage(lang: string) {
    this.currentLanguage.next(lang);
    localStorage.setItem('lang', lang);
  }

  translate(key: string): string {
    return this.translations[this.currentLanguage.value][key] || key;
  }
}
